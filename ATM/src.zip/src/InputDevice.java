public interface InputDevice {
   String getInput(String Input);
}
