public class ATM{
    Bank MyBank;
    public ATM(Bank bank) {
        this.MyBank = bank;
    }
}