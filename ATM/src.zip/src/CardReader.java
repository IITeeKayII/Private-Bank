import java.io.BufferedReader;
import java.io.InputStreamReader;

public class CardReader extends HardwareElement implements InputDevice {

    public CardReader(String Name) {
        super(Name);
        BufferedReader buffer = new BufferedReader(new InputStreamReader(System.in));
    }

    public String getInput(String Input) {
        return null;
    }
}