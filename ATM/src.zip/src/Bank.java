import java.util.*;
public class Bank{
public Map<String, Client> accounts;
Client Coen;
Client Kevin;

        public Bank() {
                HashMap<String ,Client> map = new HashMap<String, Client>();
                Coen = new Client("Coen", "SU90USSR1234567898", 500);
                Kevin = new Client("Kevin", "SU90USSR9876543212", 500);
                accounts.put("Coen", Coen);
                accounts.put("Kevin", Kevin);
        }
        public Client getCoen(String rekeningnummer){
                if(rekeningnummer.equals(Coen.getPin())){
                        return Coen;
                } else {
                        return null;
                }
        }
        public Client getKevin(String rekeningnummer){
                if(rekeningnummer.equals(Kevin.getPin())){
                        return Kevin;
                } else {
                        return null;
                }
        }


}