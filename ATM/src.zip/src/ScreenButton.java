import java.awt.*;

public class ScreenButton extends ScreenElement implements InputDevice {
    public ScreenButton(String Name, Point pos) {
        super(Name, pos);
    }

    void setContainer(Container myContainer) {

    }

    public String getInput(String Input) {
        return null;
    }
}
