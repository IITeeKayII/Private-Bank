import java.io.BufferedReader;
import java.io.InputStreamReader;

public class Keypad extends HardwareElement implements InputDevice{


    public Keypad(String Name) {
        super(Name);
        BufferedReader buffer = new BufferedReader(new InputStreamReader(System.in));
    }

    public String getInput(String Input) {
        return null;
    }

}
