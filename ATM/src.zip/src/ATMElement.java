public abstract class ATMElement {
    public ATMElement(String Name) {
    }
}
