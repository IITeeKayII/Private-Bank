public interface OutputDevice {
    String giveOutput(String Output);
}
