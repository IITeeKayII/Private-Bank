public class Client {
    private String Name;
    private String pin;
    private int balance;

    public Client(String Name, String pin, int balance) {
        this.Name = Name;
        this.pin = pin;
        this.balance = balance;
    }

    public String getName() {
        return Name;
    }

    public boolean checkPin(String pin) {
        if (this.pin.equals(pin)) {
            return true;
        } else return false;
    }

    public int getBalance(String pin) {
        if (checkPin(this.pin) == true) {
            return balance;
        } else {
            return Integer.MIN_VALUE;
        }
    }
    public void deposit(int deposited){
    balance = balance + deposited;
    }
    public boolean Withdraw(int ToWithdraw, String pin){
        checkPin(this.pin);
        if (checkPin(this.pin) == true && balance > ToWithdraw){
            balance = balance - ToWithdraw;
            return true;
        } else{
            return false;
        }
    }

    public String getPin() {
        return pin;
    }
}
