import java.awt.*;

public class DisplayText extends ScreenElement implements OutputDevice {
    public DisplayText(String Name, Point pos) {
        super(Name, pos);
    }

    void setContainer(Container myContainer) {

    }

    public String giveOutput(String Output) {
        return null;
    }
}
